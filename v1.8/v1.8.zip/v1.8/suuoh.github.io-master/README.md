melvin.io
=========

About
-----
Welcome to the GitHub project for my personal website!

Licenses
--------
Please see the [Licenses](LICENSES.md) file.

Personal Notes
---------
[Improving 404](https://webdesign.tutsplus.com/articles/user-experience-articles/improving-404-page-design/)  
[GitHub Styleguide](https://github.com/styleguide)  
[Understand the Favicon](http://www.jonathantneal.com/blog/understand-the-favicon/)  
