melvin.io
=========

Licenses
--------
The following files, directories, and their contents are Copyright © 2014 Melvin Chien with all rights reserved - please ask me before you reuse anything:
* blog/
* images/
* about.html
* portfolio.html

All other files are Copyright © 2014 Melvin Chien and licensed under the [MIT License](LICENSE), unless otherwise stated.  

#### Font Awesome
**Author:** Dave Gandy  
**Website:** <http://fortawesome.github.com/Font-Awesome>  
**License:** [SIL Open Font License](http://scripts.sil.org/OFL)  

#### Foundation
**Author:** ZURB  
**Website:** <http://foundation.zurb.com>  
**License:** [MIT License](http://github.com/zurb/foundation/blob/master/LICENSE)  

#### jQuery
**Author:** jQuery Foundation  
**Website:** <http://jquery.com/>  
**License:** [MIT License](http://github.com/jquery/jquery/blob/master/MIT-LICENSE.txt)  

#### jQuery Address
**Author:** Rostislav Hristov, Asual DZZD  
**Website:** <http://www.asual.com/jquery/address/>  
**License:** [MIT License](http://github.com/asual/jquery-address/blob/master/MIT-LICENSE)  

#### LESS Elements
**Author:** Dmitry Fadeyev  
**Website:** <http://lesselements.com/>  
**License:** [None](https://github.com/dmitryf/elements/blob/master/README.md)  

#### Modernizr
**Author:** Faruk Ates, Paul Irish, and Alex Sexton  
**Website:** <http://modernizr.com/>  
**License:** [MIT License](http://modernizr.com/license/)  

#### Normalize
**Author:** Nicolas Gallagher and Jonathan Neal  
**Website:** <http://necolas.github.io/normalize.css/>  
**License:** [MIT License](http://github.com/necolas/normalize.css/blob/master/LICENSE.md)  
