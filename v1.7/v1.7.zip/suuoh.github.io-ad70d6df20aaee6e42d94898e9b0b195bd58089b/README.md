melvin.io
=========

About
-----
Welcome to the GitHub project for my personal website!

Licenses
--------
Licenses for all files can be found in the [LICENSES](LICENSES.md) file.

Resources
---------
[Improving 404](http://webdesign.tutsplus.com/articles/user-experience-articles/improving-404-page-design/)  
[GitHub Styleguide](http://github.com/styleguide)  
[adamralph](http://github.com/adamralph/adamralph.github.com)  
[tha](http://tha.jp/)  
[Why Informatics](http://www.soic.indiana.edu/prospective/_doc/why-info-groth.pdf)  
[LESS2CSS](http://less2css.org/)  
[JS2Coffee](http://js2coffee.org/)  